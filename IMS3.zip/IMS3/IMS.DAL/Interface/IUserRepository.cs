﻿using IMS.Entity.Models;
namespace IMS.DAL.Interface
{
    public interface IUserRepository<T>
    {
        public List<User> GetAll();
        public User GetById(int Id);
        public User GetByUsername(string Username);
        public User Create(User _object);
        public User Update(User _object);
        public bool Delete(User _object);
    }
}
