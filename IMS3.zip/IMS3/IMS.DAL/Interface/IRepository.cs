﻿namespace IMS.DAL.Interface
{
    public interface IRepository<T>
    {
        public List<T> GetAll();
        public T GetById(int Id);
        public T Create(T _object);
        public T Update(T _object);
        public bool Delete(T _object);
    }
}
