﻿using IMS.Entity.Models;
using IMS.DAL.Interface;
using IMS.DAL.Data;
namespace IMS.DAL.Repository
{
    public class UserRepository : IUserRepository<User>
    {
        private IMSDbContext _iMSDbContext;
        public UserRepository(IMSDbContext iMSDbContext)
        {
            _iMSDbContext = iMSDbContext;
        }
        
        public List<User> GetAll()
        {
            List<User> lstUsers = _iMSDbContext.Users.ToList();
            return lstUsers;
        }

        public User GetById(int id)
        {
            return _iMSDbContext.Users.FirstOrDefault(x => x.UserId == id);            
        }

        public User GetByUsername(string userName)
        {
            return _iMSDbContext.Users.FirstOrDefault(x => x.Username == userName);
        }

        public User Create(User user)
        {         
            _iMSDbContext.Users.Add(user);
            _iMSDbContext.SaveChanges();
            return user;
        }       

        public User Update(User user)
        {            
            _iMSDbContext.Users.Update(user);
            _iMSDbContext.SaveChanges();
            return user;
        }
       
        public bool Delete(User user)
        {            
            _iMSDbContext.Remove(user);
            _iMSDbContext.SaveChanges();
            return true;
        }
    }
}