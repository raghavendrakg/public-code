﻿using IMS.Entity.Models;
using IMS.DAL.Interface;
using IMS.DAL.Data;
namespace IMS.DAL.Repository
{
    public class ProductRepository : IRepository<Product>
    {
        private IMSDbContext _iMSDbContext;
        public ProductRepository(IMSDbContext iMSDbContext)
        {
            _iMSDbContext = iMSDbContext;
        }
        
        public List<Product> GetAll()
        {
            List<Product> lstProducts = _iMSDbContext.Products.ToList();
            return lstProducts;
        }

        public Product GetById(int id)
        {
            return _iMSDbContext.Products.FirstOrDefault(x => x.ProductId == id);            
        }

        public Product Create(Product product)
        {         
            _iMSDbContext.Products.Add(product);
            _iMSDbContext.SaveChanges();
            return product;
        }       

        public Product Update(Product product)
        {            
            _iMSDbContext.Products.Update(product);
            _iMSDbContext.SaveChanges();
            return product;
        }
       
        public bool Delete(Product product)
        {            
            _iMSDbContext.Remove(product);
            _iMSDbContext.SaveChanges();
            return true;
        }
    }
}