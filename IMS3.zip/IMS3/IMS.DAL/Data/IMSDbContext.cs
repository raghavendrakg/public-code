﻿using Microsoft.EntityFrameworkCore;
using IMS.Entity.Models;

namespace IMS.DAL.Data
{
    public class IMSDbContext : DbContext
    {        
        public IMSDbContext(DbContextOptions<IMSDbContext> options) : base(options)
        {           

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
