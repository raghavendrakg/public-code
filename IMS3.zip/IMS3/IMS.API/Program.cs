using Microsoft.EntityFrameworkCore;
using System.Web.Http;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<IMS.DAL.Data.IMSDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("IMSConnectionString")));

builder.Services.AddTransient<IMS.DAL.Interface.IRepository<IMS.Entity.Models.Product>, IMS.DAL.Repository.ProductRepository>();
builder.Services.AddTransient<IMS.BL.ProductBL, IMS.BL.ProductBL>();
builder.Services.AddTransient<IMS.DAL.Interface.IUserRepository<IMS.Entity.Models.User>, IMS.DAL.Repository.UserRepository>();
builder.Services.AddTransient<IMS.BL.UserBL, IMS.BL.UserBL>();
builder.Services.AddTransient<IMS.API.Attributes.BasicAuthenticationAttribute, IMS.API.Attributes.BasicAuthenticationAttribute>();
GlobalConfiguration.Configuration.Filters.Add(new IMS.API.Attributes.BasicAuthenticationAttribute());

var app = builder.Build();
app.UseDeveloperExceptionPage();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
