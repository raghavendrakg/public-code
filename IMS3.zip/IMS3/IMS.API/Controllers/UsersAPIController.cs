﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using IMS.Entity;
using IMS.BL;
using IMS.Entity.Models;
using IMS.DAL.Interface;
using IMS.DAL.Repository;

namespace IMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [IMS.API.Attributes.BasicAuthentication]
    public class UsersAPIController : ControllerBase
    {
        private readonly IUserRepository<User> _userRepository;
        private readonly UserBL _usersBL;
        public UsersAPIController(IUserRepository<User> userRepository, UserBL usersBL)
        {
            _userRepository = userRepository;
            _usersBL = usersBL;
        }

        [HttpGet("GetAllUsers")]
        public List<User> GetAllUsers()
        {
            return _usersBL.GetAllUsers();
        }

        [HttpGet("GetUserById/{id}")]
        public User GetUserById(int id)
        {
            return _usersBL.GetUserById(id);
        }

        [HttpGet("GetUserByUsername/{username}")]
        public User GetUserByUsername(string username)
        {
            return _usersBL.GetUserByUsername(username);
        }

        [HttpPost("CreateUser")]
        public User CreateUser(User user)
        {
            return _usersBL.CreateUser(user);
        }

        [HttpPost("UpdateUser")]
        public User UpdateUser(User user)
        {
            return _usersBL.UpdateUser(user);
        }

        [HttpPost("DeleteUser")]
        public bool DeleteUser(User user)
        {
            return _usersBL.DeleteUser(user);
        }
    }
}
