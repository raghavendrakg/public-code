﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using IMS.Entity;
using IMS.BL;
using IMS.Entity.Models;
using IMS.DAL.Interface;
using IMS.DAL.Repository;
namespace IMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsAPIController : ControllerBase
    {
        private readonly IRepository<Product> _productRepository;
        private readonly ProductBL _productsBL;
        public ProductsAPIController(IRepository<Product> productRepository, ProductBL productsBL)
        {
            _productRepository = productRepository;
            _productsBL = productsBL;
        }

        [HttpGet("GetAllProducts")]
        public List<Product> GetAllProducts()
        {
            return _productsBL.GetAllProducts();
        }

        [HttpGet("GetProductById/{id}")]
        public Product GetProductById(int id)
        {
            return _productsBL.GetProductById(id);
        }

        [HttpPost("CreateProduct")]
        public Product CreateProduct(Product product)
        {
            return _productsBL.CreateProduct(product);
        }

        [HttpPost("UpdateProduct")]
        public Product UpdateProduct(Product product)
        {
            return _productsBL.UpdateProduct(product);
        }

        [HttpPost("DeleteProduct")]
        public bool DeleteProduct(Product product)
        {
            return _productsBL.DeleteProduct(product);
        }
    }
}
