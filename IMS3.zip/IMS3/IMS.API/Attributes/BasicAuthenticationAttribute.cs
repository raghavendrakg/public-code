﻿
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using IMS.BL;
using IMS.Entity.Models;
using IMS.DAL.Interface;
namespace IMS.API.Attributes
{
    public class BasicAuthenticationAttribute : AuthorizationFilterAttribute
    {
        private readonly IUserRepository<User> _userRepository;
        private readonly UserBL _usersBL;
        public BasicAuthenticationAttribute(IUserRepository<User> userRepository, UserBL usersBL)
        {
            _userRepository = userRepository;
            _usersBL = usersBL;
        }
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            if(actionContext.Request.Headers.Authorization ==null)
            {
                actionContext.Response = actionContext.Request
                    .CreateResponse(System.Net.HttpStatusCode.Unauthorized);
            }
            else
            {
                string authenticationToken = actionContext.Request.Headers.Authorization.Parameter;
                string decodedAuthenticationToken = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(authenticationToken));
                string[] userNamePasswordArray= decodedAuthenticationToken.Split(":");
                string userName= userNamePasswordArray[0];
                string password= userNamePasswordArray[1];
                
                User user = _usersBL.GetUserByUsername(userName);
                if (userName==user.Username && password==user.Password)
                {
                    Thread.CurrentPrincipal = new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity(userName),null);
                }
                else
                {
                    actionContext.Response = actionContext.Request
                        .CreateResponse(System.Net.HttpStatusCode.Unauthorized);
                }
            }
            base.OnAuthorization(actionContext);
        }
    }
}
