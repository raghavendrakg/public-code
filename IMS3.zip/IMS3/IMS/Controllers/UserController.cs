﻿using Microsoft.AspNetCore.Mvc;
using IMS.Entity.Models;
using Newtonsoft.Json;
namespace IMS.Controllers
{
    public class UserController : Controller
    {
        private string apiUrl;
        private IConfiguration _iConfiguration;
        public UserController(IConfiguration iConfiguration)
        {
            _iConfiguration = iConfiguration;
            apiUrl = _iConfiguration.GetValue<string>("IMSSettings:ApiUrl") + "UsersAPI/";
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(User reqUser)
        {
            User user;
            using (var httpClient = new HttpClient())
            {
                StringContent inputContent = new StringContent(JsonConvert.SerializeObject(reqUser), System.Text.Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync(apiUrl + "GetUserByUsername", inputContent))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    user = JsonConvert.DeserializeObject<User>(apiResponse);
                }
            }
            return View();
        }
    }
}
