﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using IMS.Entity.Models;
using IMS.Entity.Product;
namespace IMS.Controllers
{
    public class ProductsController : Controller
    {
        private string apiUrl;
        private IConfiguration _iConfiguration;
        public ProductsController(IConfiguration iConfiguration)
        {
            _iConfiguration = iConfiguration;
            apiUrl = _iConfiguration.GetValue<string>("IMSSettings:ApiUrl") + "ProductsAPI/";
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {            
            List<Product> productList = new List<Product>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrl + "GetAllProducts"))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        productList = JsonConvert.DeserializeObject<List<Product>>(apiResponse);
                    }                    
                }
            }
            return View(productList);           
        }

        [HttpGet]
        public async Task<IActionResult> View(int id)
        {
            Product product = new Product();
            UpdateProductViewModel updateProductViewModel = new UpdateProductViewModel();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrl + "GetProductById/" + id))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        product = JsonConvert.DeserializeObject<Product>(apiResponse);
                        if (product != null)
                        {
                            updateProductViewModel.ProductId = product.ProductId;
                            updateProductViewModel.ProductName = product.ProductName;
                            updateProductViewModel.ProductCategoryId = product.ProductCategoryId;
                            updateProductViewModel.ProductPrice = product.ProductPrice;
                            updateProductViewModel.ProductQuantity = product.ProductQuantity;
                            updateProductViewModel.SupplierId = product.SupplierId;
                        }
                    }
                }
            }
            return await Task.Run(() => View("View", updateProductViewModel));
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateProductViewModel reqCreateProductViewModel)
        {
            Product product = new Product();            
            product.ProductName = reqCreateProductViewModel.ProductName;
            product.ProductCategoryId = reqCreateProductViewModel.ProductCategoryId;
            product.ProductPrice = reqCreateProductViewModel.ProductPrice;
            product.ProductQuantity = reqCreateProductViewModel.ProductQuantity;
            product.SupplierId = reqCreateProductViewModel.SupplierId;
            using (var httpClient = new HttpClient())
            {
                StringContent inputContent = new StringContent(JsonConvert.SerializeObject(product), System.Text.Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync(apiUrl + "CreateProduct", inputContent))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    product = JsonConvert.DeserializeObject<Product>(apiResponse);
                }
            }                        
            return RedirectToAction("Index");
        }



        [HttpPost]
        public async Task<IActionResult> Update(UpdateProductViewModel reqUpdateProductViewModel)
        {
            Product product = new Product();            
            product.ProductId = reqUpdateProductViewModel.ProductId;
            product.ProductName = reqUpdateProductViewModel.ProductName;
            product.ProductCategoryId = reqUpdateProductViewModel.ProductCategoryId;
            product.ProductPrice = reqUpdateProductViewModel.ProductPrice;
            product.ProductQuantity = reqUpdateProductViewModel.ProductQuantity;
            product.SupplierId = reqUpdateProductViewModel.SupplierId;
            using (var httpClientPost = new HttpClient())
            {
                StringContent inputContent = new StringContent(JsonConvert.SerializeObject(product), System.Text.Encoding.UTF8, "application/json");
                using (var response = await httpClientPost.PostAsync(apiUrl + "UpdateProduct", inputContent))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    product = JsonConvert.DeserializeObject<Product>(apiResponse);
                }
            }
            return RedirectToAction("Index");                            
        }

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateProductViewModel reqUpdateProductViewModel)
        {
            Product product = new Product();
            product.ProductId = reqUpdateProductViewModel.ProductId;
            product.ProductName = reqUpdateProductViewModel.ProductName;
            product.ProductCategoryId = reqUpdateProductViewModel.ProductCategoryId;
            product.ProductPrice = reqUpdateProductViewModel.ProductPrice;
            product.ProductQuantity = reqUpdateProductViewModel.ProductQuantity;
            product.SupplierId = reqUpdateProductViewModel.SupplierId;
            if (product == null) { return View("Error"); }
            else
            {
                using (var httpClientPost = new HttpClient())
                {
                    StringContent inputContent = new StringContent(JsonConvert.SerializeObject(product), System.Text.Encoding.UTF8, "application/json");
                    using (var response = await httpClientPost.PostAsync(apiUrl + "DeleteProduct", inputContent))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        bool IsDeleted = JsonConvert.DeserializeObject<bool>(apiResponse);
                    }
                }
                return RedirectToAction("Index");
            }
        }
    }
}
