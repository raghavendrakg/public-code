﻿namespace IMS.Entity.Product
{
    public class CreateProductViewModel
    {
        public string ProductName { get; set; } = string.Empty;
        public int ProductCategoryId { get; set; }
        public double ProductPrice { get; set; }
        public int ProductQuantity { get; set; }
        public int SupplierId { get; set; }
    }
}
