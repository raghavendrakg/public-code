﻿namespace IMS.Entity.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public int ProductCategoryId { get; set; }
        public double ProductPrice { get; set; }
        public int ProductQuantity { get; set; }
        public int SupplierId { get; set; }
    }
}
