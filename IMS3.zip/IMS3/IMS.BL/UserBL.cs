﻿using IMS.Entity.Models;
using IMS.DAL.Repository;
namespace IMS.BL
{    
    public class UserBL
    {
        private readonly UserRepository _userRepository;

        public UserBL(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }
       
        public List<User> GetAllUsers()
        {
            return _userRepository.GetAll();
        }

        public User GetUserById(int id)
        {            
            return _userRepository.GetById(id);            
        }

        public User GetUserByUsername(string userName)
        {
            return _userRepository.GetByUsername(userName);
        }

        public User CreateUser(User user)
        {                 
            return _userRepository.Create(user);
        }

        public User UpdateUser(User user)
        {
            User? user1 = _userRepository.GetById(user.UserId);
            if (user == null) { return null; }
            else
            {
                user1.UserId = user.UserId;
                user1.Username = user.Username;
                user1.Password = user.Password;                
            }
            return _userRepository.Update(user1);
        }
        
        public bool DeleteUser(User user)
        {
            User? user1 = _userRepository.GetById(user.UserId);
            if (user == null) { return false; }
            else
            {
                user.UserId = user.UserId;
                user.Username = user.Username;
                user.Password = user.Password;                
            }
            _userRepository.Delete(user1);           
            return true;
        }
    }
}