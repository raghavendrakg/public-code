﻿using IMS.Entity.Models;
using IMS.DAL.Interface;
namespace IMS.BL
{
    public class ProductBL
    {
        private readonly IRepository<Product> _productRepository;

        public ProductBL(IRepository<Product> productRepository)
        {
            _productRepository = productRepository;
        }

        public List<Product> GetAllProducts()
        {
            return _productRepository.GetAll();
        }

        public Product GetProductById(int id)
        {            
            return _productRepository.GetById(id);            
        }

        public Product CreateProduct(Product product)
        {                 
            return _productRepository.Create(product);
        }

        public Product UpdateProduct(Product product)
        {
            Product? product1 = _productRepository.GetById(product.ProductId);
            if (product == null) { return null; }
            else
            {
                product1.ProductId = product.ProductId;
                product1.ProductName = product.ProductName;
                product1.ProductCategoryId = product.ProductCategoryId;
                product1.ProductPrice = product.ProductPrice;
                product1.ProductQuantity = product.ProductQuantity;
                product1.SupplierId = product.SupplierId;  
            }
            return _productRepository.Update(product1);
        }
        
        public bool DeleteProduct(Product product)
        {
            Product? product1 = _productRepository.GetById(product.ProductId);
            if (product == null) { return false; }
            else
            {
                product.ProductId = product.ProductId;
                product.ProductName = product.ProductName;
                product.ProductCategoryId = product.ProductCategoryId;
                product.ProductPrice = product.ProductPrice;
                product.ProductQuantity = product.ProductQuantity;
                product.SupplierId = product.SupplierId;
            }
            _productRepository.Delete(product1);           
            return true;
        }
    }
}